package br.com.carrefour.lancamentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LancamentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
