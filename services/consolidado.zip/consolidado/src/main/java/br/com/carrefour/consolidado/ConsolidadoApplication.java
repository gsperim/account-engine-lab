package br.com.carrefour.consolidado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsolidadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsolidadoApplication.class, args);
	}

}
